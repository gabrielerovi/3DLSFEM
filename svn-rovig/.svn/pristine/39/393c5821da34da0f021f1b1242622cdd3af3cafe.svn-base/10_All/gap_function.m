function gap=gap_function(x,y,z)

gap= abs(z);


end