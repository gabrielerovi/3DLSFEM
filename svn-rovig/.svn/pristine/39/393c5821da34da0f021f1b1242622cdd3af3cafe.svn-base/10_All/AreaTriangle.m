function A=AreaTriangle(nodes_coord_of_face) 

   s1=nodes_coord_of_face(2,:)-nodes_coord_of_face(1,:);
   s2=nodes_coord_of_face(3,:)-nodes_coord_of_face(1,:);
   
   A= 0.5 * norm(cross(s1,s2 ));

end