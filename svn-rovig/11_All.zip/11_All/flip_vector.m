function vector=flip_vector(vector,do_I_have_to_flip_it)

if(do_I_have_to_flip_it)
    vector=fliplr(vector);
end
end